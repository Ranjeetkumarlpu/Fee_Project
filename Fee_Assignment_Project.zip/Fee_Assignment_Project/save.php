<?php
   $mysqli= new mysqli("localhost","root","","msdigital");
   if ($mysqli->connect_error)
      die("Database Connection failed".$mysql->connect_error);

   $query="insert into financial_trans(parent table) (moduleid,amount) values('".$_POST['modulid'].",".$_POST['amount']."')";
   if($mysql->query($query){
      $id = $mysqli-> insert_id;
      $cquery="";
      $count=count($_POST['style']);
       for($i=0;$i<count;$i++)
       {
             $cquery="insert into financial_transdetail(child table)(moduleid,financialTranid,amount) values(".id",
             '".$_POST['financialTranid'][$i]."','".$_POST['amount'][$i]."')";
       }

    if ($mysqli->multi_query($query){
        echo "Record Saved"
        else
          echo "amount details failed"
    }
    else{
        echo "person details saved to failed";
    }