<html>
    <title>Fee Assignment</title>
    <head>
        <style>
a:link, a:visited {
  background-color: #f44336;
  color: white;
  padding: 14px 35px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
}
center{
    padding-top:100px;
}
        </style>
</head>
    <body>
    <a href="index.php" target="_blank">Home</a>
        <center>
        <h1>Welcome To Fee Assignment</h1>
    <a href="registration.php" target="_blank">Payment Now</a>
    <a href="fee.php" target="_blank">Display Fee Details</a>
</center>
</body>
</html>