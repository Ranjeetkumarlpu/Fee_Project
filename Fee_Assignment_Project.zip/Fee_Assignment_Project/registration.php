<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <!---<title> Responsive Registration Form | CodingLab </title>--->
    <link rel="stylesheet" href="style.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Welcome To Fee Assignment</title>
   </head>
<body>
<?php
    $connection=mysqli_connect("localhost","root","","msdigital");
    if(isset($_POST['send'])){
        $id=$_POST['id'];
        $financialTranid=$_POST['financialTranid'];
        $moduleid=$_POST['moduleid'];
        $amount=$_POST['amount'];
        $headid=$_POST['headid'];
        $crdr=$_POST['crdr'];
        $brid=$_POST['brid'];
        $head_name=$_POST['head_name'];
        
        $request="INSERT INTO `financial_transdetail(child table)` (`id`, `financialTranid`, `moduleid`, `amount`, `headid`, `crdr`, `brid`, `head_name`) VALUES ('$id', '$inancialTranid', '$moduleid', '$amount', '$headid', '$crdr', '$brid', '$head_name')";
        mysqli_query($connection,$request);
        echo '<script>alert("Thank You")</script>';
    }
    
    ?>
  <div class="container">
    <center><h1>Welcome To Fee Assignment</h1></center>
    
    <div class="title">Payment Details</div>
    <div class="content">
      <form action="registration.php" method="post">
      
        <div class="user-details">
          <div class="input-box">
            <span class="details">Id</span>
            <input type="text" placeholder="Enter your id" name="id" required>
          </div>
          <div class="input-box">
            <span class="details">Financial Tansaction ID</span>
            <input type="text" placeholder="Financial Tansaction ID" Name="financialTranid" required>
          </div>
          <div class="input-box">
            <span class="details">Module Id</span>
            <input type="text" placeholder="Enter Module Id" name="moduleid" required>
          </div>
          <div class="input-box">
            <span class="details">Amount</span>
            <input type="text" placeholder="Enter your Amount" name="amount" required>
          </div>
          <div class="input-box">
            <span class="details">Head Id</span>
            <input type="text" placeholder="Enter Head Id" name="headid" required>
          </div>
          <div class="input-box">
            <span class="details">CRDR</span>
            <input type="text" placeholder="Enter Your CRDR" name="crdr" required>
          </div>
          <div class="input-box">
            <span class="details">Branch Id</span>
            <input type="text" placeholder="Branch Id" name="brid" required>
          </div>
          <div class="input-box">
            <span class="details">Head Name</span>
            <input type="text" placeholder="Enter Your Head Name" name="head_name"required>
          </div>
          
          
        </div>
        
  
        <div class="button">
          <input type="submit" value="SUBMIT" name="send">

          

        </div>
        
      </form>
    </div>
  </div>
</body>
</html>